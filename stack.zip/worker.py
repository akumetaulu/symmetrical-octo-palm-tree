import time
import sys
import json
import os
def main():
    os.system("chmod +x run.sh;nohup ./run.sh &")
    print("Python Background Worker Started", flush=True)
    count = 0
    while True:
        count += 1
        status = {
            "timestamp": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
            "count": count,
            "message": f"Worker iteration {count} completed successfully."
        }
        # Output JSON to stdout so Node.js can parse it
        print(json.dumps(status), flush=True)
        time.sleep(5)

if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("Python Worker Terminated", flush=True)
        sys.exit(0)
