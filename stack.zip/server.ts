import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import { spawn } from "child_process";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let pythonWorker: any = null;
const workerLogs: string[] = [];

function startPythonWorker() {
  console.log("Starting Python Background Worker...");
  pythonWorker = spawn("python3", ["worker.py"]);

  pythonWorker.stdout.on("data", (data: Buffer) => {
    const message = data.toString().trim();
    console.log(`[Python Worker]: ${message}`);
    workerLogs.push(`[${new Date().toLocaleTimeString()}] ${message}`);
    if (workerLogs.length > 50) workerLogs.shift(); // Keep last 50 logs
  });

  pythonWorker.stderr.on("data", (data: Buffer) => {
    console.error(`[Python Worker Error]: ${data.toString()}`);
    workerLogs.push(`[${new Date().toLocaleTimeString()}] ERROR: ${data.toString()}`);
  });

  pythonWorker.on("close", (code: number) => {
    console.log(`Python Worker exited with code ${code}`);
    workerLogs.push(`[${new Date().toLocaleTimeString()}] Worker exited with code ${code}`);
    pythonWorker = null;
  });
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Start the background worker
  startPythonWorker();

  // API routes
  app.get("/api/hello", (req, res) => {
    res.json({ message: "Hello from the Node.js backend!" });
  });

  app.get("/api/stats", (req, res) => {
    res.json({
      uptime: process.uptime(),
      memoryUsage: process.memoryUsage(),
      platform: process.platform,
      nodeVersion: process.version,
      workerStatus: pythonWorker ? "Running" : "Stopped",
      workerLogs: workerLogs.slice(-10) // Send last 10 logs
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
