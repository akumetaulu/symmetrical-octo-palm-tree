import { useState, useEffect, ReactNode } from "react";
import { motion, AnimatePresence } from "motion/react";
import { 
  Server, 
  Activity, 
  Cpu, 
  Terminal, 
  RefreshCw, 
  Database, 
  ShieldCheck,
  Globe
} from "lucide-react";

interface Stats {
  uptime: number;
  memoryUsage: {
    rss: number;
    heapTotal: number;
    heapUsed: number;
    external: number;
  };
  platform: string;
  nodeVersion: string;
  workerStatus: string;
  workerLogs: string[];
}

export default function App() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());

  const fetchStats = async () => {
    try {
      setLoading(true);
      const response = await fetch("/api/stats");
      if (!response.ok) throw new Error("Failed to fetch backend stats");
      const data = await response.json();
      setStats(data);
      setLastUpdated(new Date());
      setError(null);
    } catch (err) {
      setError(err instanceof Error ? err.message : "An unknown error occurred");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchStats();
    const interval = setInterval(fetchStats, 5000); // Poll more frequently for logs
    return () => clearInterval(interval);
  }, []);

  const formatBytes = (bytes: number) => {
    const mb = bytes / (1024 * 1024);
    return `${mb.toFixed(2)} MB`;
  };

  const formatUptime = (seconds: number) => {
    const h = Math.floor(seconds / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    return `${h}h ${m}m ${s}s`;
  };

  return (
    <div className="min-h-screen bg-[#E4E3E0] text-[#141414] font-sans selection:bg-[#141414] selection:text-[#E4E3E0]">
      {/* Header */}
      <header className="border-b border-[#141414] p-6 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="bg-[#141414] p-2 rounded-sm">
            <Server className="text-[#E4E3E0] w-6 h-6" />
          </div>
          <div>
            <h1 className="text-xl font-bold uppercase tracking-tighter italic font-serif">
              Node.js + Python Monitor
            </h1>
            <p className="text-[10px] uppercase tracking-widest opacity-50 font-mono">
              v1.1.0 // Hybrid Environment
            </p>
          </div>
        </div>
        <div className="flex items-center gap-4">
          <div className="text-right hidden sm:block">
            <p className="text-[10px] uppercase tracking-widest opacity-50 font-mono">Last Sync</p>
            <p className="text-xs font-mono">{lastUpdated.toLocaleTimeString()}</p>
          </div>
          <button 
            onClick={fetchStats}
            disabled={loading}
            className="p-2 border border-[#141414] hover:bg-[#141414] hover:text-[#E4E3E0] transition-colors disabled:opacity-50"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </header>

      <main className="p-6 max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-6">
        {/* Status Overview */}
        <section className="md:col-span-2 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <StatCard 
              icon={<Activity className="w-4 h-4" />}
              label="System Uptime"
              value={stats ? formatUptime(stats.uptime) : "---"}
              subValue="Continuous Operation"
            />
            <StatCard 
              icon={<Cpu className="w-4 h-4" />}
              label="Python Worker"
              value={stats?.workerStatus || "---"}
              subValue="Background Process"
              statusColor={stats?.workerStatus === "Running" ? "text-green-600" : "text-red-600"}
            />
          </div>

          {/* Python Worker Logs */}
          <div className="border border-[#141414] overflow-hidden">
            <div className="bg-[#141414] text-[#E4E3E0] p-3 flex items-center gap-2">
              <Terminal className="w-4 h-4" />
              <h2 className="text-xs uppercase tracking-widest font-bold">Python Worker Logs</h2>
            </div>
            <div className="bg-black text-[#00FF00] p-4 font-mono text-[11px] h-64 overflow-y-auto space-y-1">
              {stats?.workerLogs && stats.workerLogs.length > 0 ? (
                stats.workerLogs.map((log, i) => (
                  <p key={i} className="opacity-80 border-b border-[#00FF00]/10 pb-1">{log}</p>
                ))
              ) : (
                <p className="opacity-50 italic">Waiting for logs...</p>
              )}
              <div className="animate-pulse">_</div>
            </div>
          </div>

          {/* Memory Usage Table */}
          <div className="border border-[#141414] overflow-hidden">
            <div className="bg-[#141414] text-[#E4E3E0] p-3 flex items-center gap-2">
              <Database className="w-4 h-4" />
              <h2 className="text-xs uppercase tracking-widest font-bold">Memory Allocation</h2>
            </div>
            <div className="divide-y divide-[#141414]">
              <DataRow label="RSS (Resident Set Size)" value={stats ? formatBytes(stats.memoryUsage.rss) : "---"} />
              <DataRow label="Heap Total" value={stats ? formatBytes(stats.memoryUsage.heapTotal) : "---"} />
              <DataRow label="Heap Used" value={stats ? formatBytes(stats.memoryUsage.heapUsed) : "---"} />
            </div>
          </div>
        </section>

        {/* Sidebar Info */}
        <aside className="space-y-6">
          <div className="border border-[#141414] p-6 space-y-4">
            <div className="flex items-center gap-2 mb-2">
              <ShieldCheck className="w-5 h-5" />
              <h3 className="font-serif italic font-bold">Process Isolation</h3>
            </div>
            <p className="text-sm leading-relaxed opacity-70">
              The Python script is spawned as a child process using Node's <code className="bg-[#141414]/10 px-1 rounded">child_process.spawn</code>. This allows for true background execution independent of the main event loop.
            </p>
          </div>

          <div className="border border-[#141414] p-6 bg-[#141414] text-[#E4E3E0]">
            <div className="flex items-center gap-2 mb-4">
              <Globe className="w-5 h-5" />
              <h3 className="font-serif italic font-bold">System Context</h3>
            </div>
            <div className="space-y-3">
              <div>
                <p className="text-[10px] uppercase tracking-widest opacity-50">Node.js Version</p>
                <p className="text-sm font-mono">{stats?.nodeVersion || '---'}</p>
              </div>
              <div>
                <p className="text-[10px] uppercase tracking-widest opacity-50">Platform</p>
                <p className="text-sm font-mono">{stats?.platform || '---'}</p>
              </div>
            </div>
          </div>
        </aside>
      </main>

      <footer className="mt-12 border-t border-[#141414] p-6 text-center">
        <p className="text-[10px] uppercase tracking-[0.2em] opacity-30">
          Node.js // Express // Python 3 // React // Vite
        </p>
      </footer>
    </div>
  );
}

function StatCard({ icon, label, value, subValue, statusColor }: { icon: ReactNode, label: string, value: string, subValue: string, statusColor?: string }) {
  return (
    <div className="border border-[#141414] p-5 bg-white hover:bg-[#141414] hover:text-[#E4E3E0] transition-all group">
      <div className="flex items-center gap-2 mb-3 opacity-50 group-hover:opacity-100 transition-opacity">
        {icon}
        <span className="text-[10px] uppercase tracking-widest font-bold">{label}</span>
      </div>
      <div className="space-y-1">
        <p className={`text-2xl font-mono font-bold tracking-tighter ${statusColor || ''}`}>{value}</p>
        <p className="text-[10px] uppercase tracking-widest opacity-50 group-hover:opacity-70">{subValue}</p>
      </div>
    </div>
  );
}

function DataRow({ label, value }: { label: string, value: string }) {
  return (
    <div className="flex justify-between items-center p-4 hover:bg-[#141414]/5 transition-colors">
      <span className="text-xs font-serif italic">{label}</span>
      <span className="text-sm font-mono font-bold">{value}</span>
    </div>
  );
}
